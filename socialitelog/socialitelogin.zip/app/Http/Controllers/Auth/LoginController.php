<?php
namespace App\Http\Controllers\Auth;
use App\Http\Controllers\Controller;
// use App\Http\Controllers\Auth\LoginController;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Socialite;
use AppUser;
use Auth;

class LoginController extends Controller
{
    use AuthenticatesUsers;
    protected $redirectTo = '/home';
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    public function socialLogin($social) {
      return Socialite::driver($social)->redirect();
    }

    public function handleProviderCallback($social){
      $userSocial = Socialite::driver($social)->user();
      $user = User::where(['email' => $userSocial->getEmail()])->first();
      if ($user) {
        Auth::login($user);
        return redirect()->action('HomeController@index');
      } else {
        return view('auth.register', ['name' => $userSocial->getName(),'email'=> $userSocial->getEmail()]);
      }
    }
}